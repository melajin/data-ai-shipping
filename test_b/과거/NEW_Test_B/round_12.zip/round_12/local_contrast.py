"""Round 12: spatially relevant reinspection contexts with count-matched controls."""
from matched_contrast import *
from sklearn.cluster import KMeans

def main():
    s,base=load();fit=s.split.eq('FIT').to_numpy();q=~fit;sub=s.loc[q];tu=sub.split.eq('TUNE').to_numpy();re=~tu;y=s.y.to_numpy();fi=np.flatnonzero(fit)
    x={v:base[v].join(pd.read_csv(B/f'layout_features_{v}.csv',index_col='id').reindex(s.index)) for v in VIEWS}
    rd=B/'round_12'
    if not rd.exists():
        rd=setup_round(12,{'design':'region-conditioned pairwise TabICLv2 reference contexts',
            'core_change_from_previous':'Replace the nationwide FIT pool for pair reinspection with nearby FIT references selected without target labels; four geographic reference groups per observation window.',
            'training_task':'Keep round11 shared candidate head. Each vessel receives all six class-pair reinspection tasks. Nearby-reference pair evidence receives fixed .75 weight and global pair evidence .25; a TUNE-selected joint/pair policy produces final decisions.',
            'ensemble':4,'primary':'Local references, fixed before metrics. Random references are controls, not candidates for REPORT selection.',
            'reference_selection':'FIT-only KMeans four groups on projected whole-hull centers. Each query chooses nearest FIT center; select 1536 nearest FIT vessels to that center, plus nearest references to ensure at least16 for every class. No query labels, IDs, or cross-year history used.',
            'control':'For each region/window draw random FIT vessels with exactly the same per-class counts as local reference. Same model seeds/ensemble, input features and policy search. Also report random references under the frozen local decision policy.',
            'policy':'Same per-view TUNE Micro-first 192 choices as round11. No change in evaluation split or denominator.',
            'scope':'Conditional retrospective research only. Regional reference selection does not establish regional or temporal generalization.'})
        shutil.copy2(Path(__file__),rd/Path(__file__).name);shutil.copy2(B/'matched_contrast.py',rd/'matched_contrast.py')
    pair_by_arm={a:{} for a in ['local','random']};provenance=[]
    for vi,v in enumerate(VIEWS):
        xy=x[v][['loc_hull_x_m','loc_hull_y_m']].to_numpy()/1000
        assert np.isfinite(xy).all()
        km=KMeans(n_clusters=4,random_state=SEED+1200,n_init=10).fit(xy[fit]);group=km.predict(xy[q])
        np.savez(rd/f'geographic_assignment_{v}.npz',ids=sub.index.to_numpy(),group=group,centers_km=km.cluster_centers_)
        raw={a:np.ones((q.sum(),4,4)) for a in ['local','random']}
        for g in range(4):
            dist=np.linalg.norm(xy[fit]-km.cluster_centers_[g],axis=1);order=fi[np.argsort(dist,kind='stable')]
            selected=set(order[:1536])
            for c in range(4):selected.update(order[y[order]==c][:16])
            local=np.array(sorted(selected));counts=np.bincount(y[local],minlength=4)
            rng=np.random.default_rng(SEED+12000+vi*10+g)
            rand=np.sort(np.concatenate([rng.choice(fi[y[fi]==c],counts[c],replace=False) for c in range(4)]))
            assert np.array_equal(np.bincount(y[rand],minlength=4),counts)
            z=group==g
            for arm,ctx in [('local',local),('random',rand)]:
                assert not(set(s.index[ctx])&set(sub.index))
                np.save(rd/f'context_{v}_{g}_{arm}.npy',s.index[ctx].to_numpy())
                provenance.append({'view':v,'region':g,'arm':arm,'n_context':len(ctx),'class_counts':counts.tolist(),
                    'n_query':int(z.sum()),'context_query_id_overlap':0,
                    'context_center_distance_km_median':float(np.median(np.linalg.norm(xy[ctx]-km.cluster_centers_[g],axis=1)))})
                for a,b in itertools.combinations(range(4),2):
                    fn=rd/f'pair_{v}_{g}_{arm}_{a}_{b}.npy';cx=ctx[np.isin(y[ctx],[a,b])]
                    if fn.exists():pa=np.load(fn)
                    else:
                        pp,cc=predict(x[v].iloc[cx],y[cx],x[v].loc[q].iloc[np.flatnonzero(z)],SEED+1100+10*a+b,4)
                        pa=pp[:,list(cc).index(a)];np.save(fn,pa)
                    raw[arm][z,a,b]=pa;raw[arm][z,b,a]=1-pa
                print('REFERENCE_GROUP_DONE',v,g,arm,counts.tolist(),flush=True)
        glob=np.load(B/'round_11'/f'pair_{v}.npy')
        for arm in raw:
            pair_by_arm[arm][v]=.75*raw[arm]+.25*glob
            np.save(rd/f'{arm}_pair_{v}.npy',pair_by_arm[arm][v])
        dump(rd/'reference_provenance.json',provenance)
    prob={v:np.load(B/'round_11'/f'prob_{v}.npy') for v in VIEWS}
    ts=np.array(json.loads((B/'round_11'/'thresholds.json').read_text(encoding='utf-8')))
    decisions={};preds={};control={}
    for arm in ['local','random']:
        decisions[arm]={};preds[arm]={}
        for v in VIEWS:
            alpha,w,key=policy(prob[v][tu],pair_by_arm[arm][v][tu],sub.y.to_numpy()[tu])
            decisions[arm][v]={'pair_log_evidence_weight':alpha,'class_weights':w.tolist(),'TUNE_micro':key[0]/tu.sum(),'TUNE_macro':key[1]}
            preds[arm][v]=apply_policy(prob[v],pair_by_arm[arm][v],alpha,w)
    dump(rd/'decision_policy.json',decisions) # Freeze before REPORT evaluation.
    for v in VIEWS:
        np.save(rd/f'prob_{v}.npy',prob[v]);d=decisions['local'][v]
        swapped=apply_policy(prob[v],pair_by_arm['random'][v],d['pair_log_evidence_weight'],np.array(d['class_weights']))
        control[v]={}
        for sp,z in [('TUNE',tu),('REPORT',re)]:
            yy=sub.y.to_numpy()[z];control[v][sp]={'local':metrics(yy,preds['local'][v][z]),
                'count_matched_random_same_policy_search':metrics(yy,preds['random'][v][z]),
                'random_under_frozen_local_policy':metrics(yy,swapped[z])}
    dump(rd/'controlled_diagnostics.json',control);dump(rd/'thresholds.json',ts.tolist())
    m=evaluate(rd,s,base,prob,ts,preds['local'],{v:{'proposal':prob[v].argmax(1),'random_control_prediction':preds['random'][v]} for v in VIEWS})
    cmp={};yy=sub.y.to_numpy()[re]
    for n in [2,10,11]:
        old=pd.read_csv(B/f'round_{n:02}'/'predictions_full.csv',index_col='id').reindex(sub.index[re]);assert np.array_equal(old.y.to_numpy(),yy)
        cmp[f'round{n}']=bootstrap_delta(preds['local']['full'][re],old.prediction.to_numpy(),yy)
    cmp['random_count_matched']=bootstrap_delta(preds['local']['full'][re],preds['random']['full'][re],yy)
    dump(rd/'paired_comparisons.json',cmp)
    finish_round(12,m,'Spatial reference selection tested against random references with identical per-class context counts. No REPORT-based model selection; policy fixed on TUNE. Primary output remains four-class candidate evidence plus six reinspection contrasts.')
    print('LOCAL_CONTROL_FULL',json.dumps({sp:{a:mm['micro_f1'] for a,mm in vals.items()} for sp,vals in control['full'].items()}),flush=True)
    print('PAIRED_COMPARISONS',json.dumps(cmp),flush=True)

if __name__=='__main__':main()
